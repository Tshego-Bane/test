import React, { Component, useContext, useState } from "react";
import { BsApple } from "react-icons/bs";
import { FcGoogle } from "react-icons/fc";
import DataContext from "../services/dataContext";
import { useNavigate } from "react-router-dom";

const SIgnIn = () => {
  const [formData, setFormData] = useState({});
  const { setUser, users } = useContext(DataContext);
  let navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    console.log(formData);
    console.log("Users: ", users);
    let person = users.filter((per) => per.username == formData.username);
    console.log("Person: ", person);
    if (person.length != 0) {
      person = person[0];
      if (person.password == formData.password) {
        setUser(person);
        // navigate to next page
        navigate("/home");
        alert("successfuly loggged in");
      } else {
        alert("wrong password");
      }
    } else {
      alert("user not found!\nPlease register an account first");
    }
  }

  return (
    <form className="mt-4 text-left">
      <h3 className="text-left">Sign In</h3>
      <p>Input your brainy account</p>
      <div className="mb-3">
        <label>username</label>
        <input
          type="email"
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, username: e.target.value }))
          }
          className="form-control"
          placeholder="Enter username "
        />
      </div>
      <div className="mb-3">
        <label>Password</label>
        <input
          type="password"
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, password: e.target.value }))
          }
          className="form-control"
          placeholder="Enter password"
        />
      </div>
      <div className="mb-3">
        <div className="custom-control custom-checkbox">
          <input
            type="checkbox"
            className="custom-control-input"
            id="customCheck1"
          />
          <label className="custom-control-label" htmlFor="customCheck1">
            Remember me
          </label>
        </div>
      </div>
      <p className="forgot-password text-right">
        Forgot <a href="#">password?</a>
      </p>
      <div className="d-grid">
        <button
          type="submit"
          className="btn btn-warning mb-2"
          onClick={handleSubmit}
        >
          sign in Now
        </button>
        <button
          type="submit"
          className="btn btn-warning"
          onClick={() => navigate("/signUp")}
        >
          sign up
        </button>
      </div>
      <hr />
      <div>
        <button
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-evenly",
            border: "1px solid black",
            padding: "5px",
            marginBottom: "5px",
            border: "none",
            borderRadius: "10px",
          }}
        >
          <BsApple />
          Sign in with Apple
        </button>
      </div>
      <div>
        <button
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-evenly",
            border: "1px solid black",
            padding: "5px",
            arginBottom: "5px",
            border: "none",
            borderRadius: "10px",
          }}
          onClick={() => alert("Google Sign in")}
        >
          <FcGoogle width={50} height={50} />
          Sign in with Google
        </button>
      </div>
    </form>
  );
};

export default SIgnIn;
