import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import "bootstrap/dist/css/bootstrap.min.css";
import Explore from "./explore";
import Booking from "./booking";
import Account from "./account";

const TabMenu = () => {
  return (
    <Tabs
      defaultActiveKey="explore"
      transition={false}
      id="noanim-tab-example"
      className="mb-3"
    >
      <Tab eventKey="explore" title="Explore">
        <Explore />
      </Tab>
      <Tab eventKey="booking" title="Booking">
        <Booking />
      </Tab>
      <Tab eventKey="profile" title="Profile">
        <Account />
      </Tab>
    </Tabs>
  );
};

export default TabMenu;
