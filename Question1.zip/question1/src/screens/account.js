import DataContext from "../services/dataContext";
import beach from "../materials/Explore/image-14.png";
import propfilePic from "../materials/Account/profile-1 copy.png";
import mimo from "../materials/Account/Memoji Boys 6-18.png";
import { CircularProgressbar } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import { IoIosArrowForward } from "react-icons/io";
import ico from "../materials/Account/beach-with-umbrella_1f3d6-fe0f 1.png";
import message from "../materials/Account/image 9.png";
import { useContext } from "react";
import { useNavigate } from "react-router-dom";

const Account = () => {
  const { user, setUser } = useContext(DataContext);
  const percentage = Math.floor(Math.random() * 100) + 1;
  const navigate = useNavigate();

  function siggnOut() {
    setUser({});
    navigate("/signIn");
  }

  return (
    <div className="mb-5 mt-5">
      <div
        style={{
          backgroundImage: `url("https://good-nature-blog-uploads.s3.amazonaws.com/uploads/2022/01/good-nature-homepage-hero_2-scaled.jpg")`,
          backgroundRepeat: "no-repeat",
          height: "300px",
          backgroundSize: "cover",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "20px",
          borderRadius: "10px",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            color: "white",
          }}
        >
          <h2>Account</h2>
          <button
            style={{
              border: "none",
              backgroundColor: "transparent",
              color: "white",
            }}
            onClick={siggnOut}
          >
            Sign out
          </button>
        </div>
      </div>

      <div>
        <img
          src={user.link}
          width="30%"
          style={{ borderRadius: "50px", marginTop: "10px" }}
        />
        <h3>{user.username}</h3>
        <p>{user.username}@gmail.com</p>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            padding: "15px",
            borderRadius: "10px",
            boxShadow: "0px 1px 2px",
            width: "50%",
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <img src={mimo} />
            <div style={{ width: "20%", height: "20%" }}>
              <CircularProgressbar
                value={percentage}
                text={`${percentage}%`}
                width={10}
                styles={{ width: "20px" }}
              />
            </div>
          </div>
          <p>Complete your profile to get more discounts</p>
          <a href="#">
            Complete your profile now <IoIosArrowForward />
          </a>
        </div>

        <div
          style={{
            display: "felx",
            flexDirection: "column",
            justifyContent: "space-between",
            width: "40%",
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <img src={ico} />
            <div>
              <h3>12</h3>
              <p>Staycation Visited</p>
            </div>
          </div>
          <hr />
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-between",
            }}
          >
            <img src={message} />
            <div>
              <h3>10</h3>
              <p>Reviews given</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
