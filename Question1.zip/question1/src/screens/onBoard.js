import React, { Component } from "react";
import ReactDOM from "react-dom";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import { AiOutlineArrowRight } from "react-icons/ai";
import img1 from "../materials/Onboarding/On1.png";
import img2 from "../materials/Onboarding/On2.png";
import img3 from "../materials/Onboarding/On3.png";
import { Link } from "react-router-dom";

const OnBoarding = () => {
  return (
    <Carousel style={{ width: "90%", margin: "auto" }}>
      <div style={{ width: "50%", margin: "auto" }}>
        <h5>Luxury and Classy hotels</h5>
        <p>
          The best quality hotels and staycationwith international standards are
          curated
        </p>
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-end",
          }}
        >
          <Link
            to="/signIn"
            style={{
              backgroundColor: "yellow",
              borderRadius: "90px",
              padding: "17px",
              textDecoration: "none",
              margin: "5px",
            }}
          >
            <label>Skip</label>
            {"  "}
            <AiOutlineArrowRight />
          </Link>
        </div>
        <div>
          <img src={img1} alt="img1" />
        </div>
      </div>
      <div style={{ width: "50%", margin: "auto" }}>
        <h5>Luxury and Classy hotels</h5>
        <p>
          The best quality hotels and staycationwith international standards are
          curated
        </p>
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-end",
          }}
        >
          <Link to="/signIn">
            <label>Skip</label>
            <AiOutlineArrowRight />
          </Link>
        </div>
        <div>
          <img src={img2} alt="img1" />
        </div>
      </div>
      <div style={{ width: "50%", margin: "auto" }}>
        <h5>Luxury and Classy hotels</h5>
        <p>
          The best quality hotels and staycationwith international standards are
          curated
        </p>
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "flex-end",
          }}
        >
          <Link to="/signIn">
            <label>Skip</label>
            <AiOutlineArrowRight />
          </Link>
        </div>
        <div>
          <img src={img2} alt="img1" />
        </div>
      </div>
    </Carousel>
  );
};

export default OnBoarding;
