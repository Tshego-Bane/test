import { useContext, useState } from "react";
import DataContext from "../services/dataContext";
import room from "../materials/MyBooking/room.png";
import { Navigate } from "react-router-dom";
import { BsArrowLeftRight } from "react-icons/bs";

const Booking = () => {
  const { currentPlace, setHistory, history } = useContext(DataContext);
  const [toggle, setToggle] = useState(true);

  return (
    <div style={{ margin: "20px" }}>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          backgroundColor: "lightgrey",
          borderRadius: "30px",
        }}
      >
        <button
          onClick={() => setToggle(true)}
          style={
            toggle
              ? {
                  padding: "10px",
                  borderRadius: "20px",
                  backgroundColor: "white",
                  width: "50%",
                  border: "none",
                  boxShadow: "0px 0px 2px",
                }
              : {
                  padding: "10px",
                  width: "50%",
                  border: "none",
                  background: "transparent",
                }
          }
        >
          upcoming
        </button>
        <button
          onClick={() => setToggle(false)}
          style={
            !toggle
              ? {
                  padding: "10px",
                  borderRadius: "20px",
                  backgroundColor: "white",
                  width: "50%",
                  border: "none",
                  boxShadow: "0px 0px 2px",
                }
              : {
                  padding: "10px",
                  width: "50%",
                  border: "none",
                  background: "transparent",
                }
          }
        >
          History
        </button>
      </div>

      {toggle ? (
        <UpComing currentPlace={currentPlace} />
      ) : history.length > 0 ? (
        <History />
      ) : (
        <h1 style={{ margin: "30px", color: "grey" }}>No History found</h1>
      )}
    </div>
  );
};

const UpComing = () => {
  const date = new Date();
  const { currentPlace, setHistory } = useContext(DataContext);
  return (
    <div>
      <div
        style={{
          width: "100%",
          overflow: "hidden",
          borderRadius: "20px",
          marginTop: "20px",
        }}
      >
        <img
          src={currentPlace.pic}
          alt="place"
          style={{ backgroundSize: "cover", borderRadius: "20px" }}
        />
      </div>

      <div>
        <h1>{currentPlace.locName}</h1>
        <p>{currentPlace.loc}</p>
        <p>pool</p>
        <span>
          <img src={room} alt="room" />
          {currentPlace.rooms}
        </span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <div>
          <p>check in</p>
          <h4>{currentPlace.dateIn}</h4>
        </div>
        <hr />
        <div>
          <p>check out</p>
          <h4>{currentPlace.dateOut}</h4>
        </div>
      </div>

      <button
        style={{
          backgroundColor: "yellow",
          borderRadius: "10px",
          padding: "10px",
          width: "100%",
          margin: "auto",
        }}
        onClick={() => {
          setHistory((prev) => [...prev, currentPlace]);
          alert("added to history!");
        }}
      >
        Mark as history
      </button>
    </div>
  );
};

const History = () => {
  const { history } = useContext(DataContext);
  return (
    <div>
      {history.map((hist) => (
        <div
          onClick={() => alert("what did you think wpuld happen??")}
          style={{
            display: "flex",
            flexDirection: "row",
            margin: "20px",
            width: "100%",
          }}
        >
          <img
            src={hist.pic}
            alt="display pic"
            style={{ width: "150px", height: "100px", size: "cover" }}
          />
          <div
            style={{
              textAlign: "left",
              paddingLeft: "20px",
              width: "100%",
            }}
          >
            <h5>{hist.locName}</h5>
            <span style={{ margin: "5px" }}>
              <BsArrowLeftRight
                style={{ color: "blue", marginRight: "10px" }}
              />
              {hist.rooms}
            </span>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                width: "100%",
                alignContent: "center",
                alignItems: "center",
              }}
            >
              <div>
                Check-In <br />
                {hist.dateIn}
              </div>
              <div style={{ textAlign: "right" }}>
                Check-Out <br />
                {hist.dateOut}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Booking;
