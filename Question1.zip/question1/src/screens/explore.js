import profilePic from "../materials/Explore/profile-1 copy.png";

import search from "../materials/Explore/search.png";
import pin from "../materials/pin.jpg";
import { BsArrowLeftRight } from "react-icons/bs";
import star from "../materials/Explore/star.png";
import { useContext, useState } from "react";
import DataContext from "../services/dataContext";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import { FaSearchLocation } from "react-icons/fa";
import { GoStar } from "react-icons/go";
import locIcon from "../materials/loc.png";

const Explore = () => {
  const { user, currentPlace, setCurrentPlace, places, setPlaces } = useContext(
    DataContext
  );
  const [copy, setCopy] = useState(places);
  const [isSearch, setIsSearch] = useState(false);
  const dimg =
    "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__340.jpg";
  console.log("users", user);
  function handleSearch(text) {
    if (text) {
      const filteredPlaces = places.filter((place) =>
        place.locName.toLowerCase().includes(text.toLowerCase())
      );
      setPlaces(filteredPlaces);
      setIsSearch(true);
    } else {
      setIsSearch(false);
      setPlaces(copy);
    }
  }

  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
        }}
      >
        <h1 style={{ color: "grey" }}>{user.username}</h1>
        <div style={{}}>
          <img
            src={user.link ? user.link : dimg}
            alt="profile pic"
            style={{
              width: "70px",
              height: "60px",
              borderRadius: "80px",
              marginBottom: "20px",
            }}
          />
        </div>
      </div>

      {isSearch ? (
        <div>
          <div
            style={{
              width: "90%",
              margin: "auto",
              backgroundColor: "white",
              padding: "10px",
              borderRadius: "30px",
            }}
          >
            <FaSearchLocation />
            <input
              placeholder="Where do you want to stay?"
              style={{ width: "85%", border: "none" }}
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>
          <hr />
          <h6>search results:</h6>
        </div>
      ) : (
        <div
          style={{
            backgroundImage: `url(${currentPlace.pic})`,
            backgroundRepeat: "no-repeat",
            height: "500px",
            backgroundSize: "cover",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <div style={{ width: "80%", margin: "auto" }}>
            <InputGroup className="mb-3">
              <InputGroup.Text id="basic-addon1">
                <FaSearchLocation width={50} height={100} />
              </InputGroup.Text>
              <Form.Control
                placeholder="Search location"
                aria-label="Username"
                aria-describedby="basic-addon1"
                onChange={(e) => handleSearch(e.target.value)}
              />
            </InputGroup>
          </div>

          <div style={{ marginTop: "50px", color: "white" }}>
            <span>
              <span
                style={{
                  padding: "10px",
                  borderRadius: "20px",
                  backgroundColor: "white",
                  color: "black",
                  // fontSize: "16pt",
                }}
              >
                <GoStar
                  style={{ width: "30px", color: "gold", height: "30px" }}
                />
                {"  "}
                {currentPlace.rating}
              </span>
              <span
                style={{
                  padding: "10px",
                  borderRadius: "20px",
                  backgroundColor: "white",
                  color: "black",
                  marginLeft: "10px",
                }}
              >
                <img src={pin} alt="pin" style={{ width: "30px" }} />{" "}
                {currentPlace.loc}
              </span>
            </span>
            <h2 style={{ margin: "20px" }}>{currentPlace.locName}</h2>
            <p>Start from {currentPlace.price} per night</p>
          </div>
        </div>
      )}
      <hr />

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          width: "100%",
        }}
      >
        <div>
          <h5 style={{ textAlign: "left" }}>Nearby</h5>
          <span>
            <img src={pin} alt="pin" style={{ width: "30px" }} /> Gauteng
            Johannesburg
          </span>
        </div>
        <div>
          <img
            src={locIcon}
            style={{ backgroundColor: "white", width: "70px" }}
          />
        </div>
      </div>

      <div style={{ width: "100%" }}>
        {places.map((place) => (
          <div
            onClick={() => setCurrentPlace(place)}
            style={{
              display: "flex",
              flexDirection: "row",
              margin: "20px",
              width: "100%",
            }}
          >
            <img
              src={place.pic}
              alt="display pic"
              style={{ width: "150px", height: "100px", size: "cover" }}
            />
            <div
              style={{
                textAlign: "left",
                paddingLeft: "20px",
                width: "100%",
              }}
            >
              <h5>{place.locName}</h5>
              <span style={{ margin: "5px" }}>
                <BsArrowLeftRight
                  style={{ color: "blue", marginRight: "10px" }}
                />
                12.3km
              </span>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  width: "100%",
                  alignContent: "center",
                  alignItems: "center",
                }}
              >
                <div>Start from {place.price} per night </div>
                <div style={{ textAlign: "right" }}>
                  <img src={star} style={{ width: "7%", height: "20%" }} />{" "}
                  {place.rating}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Explore;
