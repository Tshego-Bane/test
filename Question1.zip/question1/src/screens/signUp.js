import React, { Component, useContext, useState } from "react";
import { BsApple } from "react-icons/bs";
import { FcGoogle } from "react-icons/fc";
import DataContext from "../services/dataContext";
import { useNavigate } from "react-router-dom";

const SIgnUp = () => {
  const [formData, setFormData] = useState({});
  const { setUser, users, setUsers } = useContext(DataContext);
  let navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    console.log(formData);
    console.log("Users: ", users);
    if (formData.username && formData.password) {
      setUser(formData);
      setUsers((prev) => [...prev, formData]);
      alert("new account created!");
      // navigate to next page
      navigate("/home");
    } else {
      alert("Please fill all the fields");
    }
  }

  return (
    <form className="mt-4 text-left">
      <h3 className="text-left">Sign up</h3>
      <p>Input your brainy account</p>
      <div className="mb-3">
        <label>Username</label>
        <input
          type="email"
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, username: e.target.value }))
          }
          className="form-control"
          placeholder="Enter username"
        />
      </div>
      <div className="mb-3">
        <label>Password</label>
        <input
          type="password"
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, password: e.target.value }))
          }
          className="form-control"
          placeholder="Enter password"
        />
      </div>
      <div className="mb-3">
        <label>Profile image link</label>
        <input
          type="url"
          onChange={(e) =>
            setFormData((prev) => ({ ...prev, link: e.target.value }))
          }
          className="form-control"
          placeholder="paste url (http:\\www.pixel.random\f45566675)"
        />
      </div>
      <div className="mb-3">
        <div className="custom-control custom-checkbox">
          <input
            type="checkbox"
            className="custom-control-input"
            id="customCheck1"
          />
          <label className="custom-control-label" htmlFor="customCheck1">
            Remember me
          </label>
        </div>
      </div>
      <p className="forgot-password text-right">
        Forgot <a href="#">password?</a>
      </p>
      <div className="d-grid">
        <button
          type="submit"
          className="btn btn-warning"
          onClick={handleSubmit}
        >
          sign up
        </button>
        <button
          type="submit"
          className="btn btn-warning mt-2"
          onClick={() => navigate("/signIn")}
        >
          Alreday have an account? sign in Now
        </button>
      </div>
    </form>
  );
};

export default SIgnUp;
