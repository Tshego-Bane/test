import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import OnBoarding from "./screens/onBoard";
import SIgnIn from "./screens/signIn";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";
import DataContext from "./services/dataContext";
import Explore from "./screens/explore";

import img1 from "./materials/Explore/image-1-3.png";
import img2 from "./materials/Explore/image-1.png";
import img3 from "./materials/Explore/image-4.png";
import img4 from "./materials/Explore/image-13.png";
import img5 from "./materials/Explore/image-14.png";
import img6 from "./materials/Explore/image-1.png";
import Booking from "./screens/booking";
import Account from "./screens/account";
import Tabs from "./screens/tabs";
import TabMenu from "./screens/tabs";
import SIgnUp from "./screens/signUp";

function App() {
  const [user, setUser] = useState({});
  const [users, setUsers] = useState([]);
  const [history, setHistory] = useState([]);
  const [currentPlace, setCurrentPlace] = useState({
    pic: img3,
    rating: 1.9,
    loc: "21 jorissen street",
    locName: "Gate way student accomodation",
    price: "R1000",
  });

  const [places, setPlaces] = useState([
    {
      pic:
        "https://www.princehotels.com/wp-content/uploads/2019/04/aboutslider2-1.jpg",
      rating: 4.9,
      loc: "222 smit street",
      locName: "Braam Gate",
      price: "R2000",
      rooms: "1 room, 2 adults",
      dateIn: "Mon 13 November",
      dateOut: "Friday 17 November",
      review: "",
    },
    {
      pic:
        "https://media-cdn.tripadvisor.com/media/photo-s/0e/1d/93/17/suite-18.jpg",
      rating: 3.4,
      loc: "12 pholong Dr",
      locName: "Betty Bnb",
      price: "R2000",
      rooms: "2 room, 4 adults",
      dateIn: "Wends 22 November",
      dateOut: "Fri  37 November",
      review: "",
    },
    {
      pic:
        "https://q-xx.bstatic.com/xdata/images/hotel/max500/159080902.jpg?k=0ca3eb65bdeb7a5992d62cb64e1bff71533d9c2e9ca56a73793a8a945b9bcc66&o=",
      rating: 1.9,
      loc: "12 henery street, johannesburg",
      locName: "Montel Casino",
      price: "R1000",
      rooms: "1 room, 2 adults 3 Children",
      dateIn: "Fri 02 Decemeber",
      dateOut: "Friday 17 december",
      review: "",
    },
    {
      pic:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRCcK3zN1xtZaUyjQpkf2Fh1eUspnIHKwkkjA&usqp=CAU",
      rating: 5,
      loc: "Jahannesburg, gauteng",
      locName: "Good stay hotel",
      price: "R1000",
      rooms: "1 room, 2 adults",
      dateIn: "Mon 13 November",
      dateOut: "Friday 17 November",
      review: "",
    },
    {
      pic:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRhwxkFMLuiRPQ8xAjtYX5-C8eVR3vTdND0A&usqp=CAU",
      rating: 4.5,
      loc: "3km away",
      locName: "Unknown",
      price: "R2000",
      rooms: "1 room, 2 adults",
      dateIn: "Mon 13 November",
      dateOut: "Friday 17 November",
      review: "",
    },
  ]);

  const values = {
    users,
    user,
    setUser,
    setUsers,
    currentPlace,
    setCurrentPlace,
    places,
    setPlaces,
    history,
    setHistory,
  };

  return (
    <div className="App" style={{ width: "40%", margin: "auto" }}>
      <DataContext.Provider value={values}>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<OnBoarding />} />
            <Route path="/signIn" element={<SIgnIn />} />
            <Route path="/signUp" element={<SIgnUp />} />
            {user.username ? (
              <Route path="/home" element={<TabMenu />} />
            ) : (
              <Route path="/home" element={<SIgnIn />} />
            )}
          </Routes>
        </BrowserRouter>
      </DataContext.Provider>
    </div>
  );
}

export default App;
